import os

_, dirs, _ = next(os.walk("."))

for dir in dirs:
    with open(f"{dir}.txt", "w") as f:
        for subdirs, dirs, files in os.walk(dir):
            for file in files:
                if file.endswith(".jpg"):
                    f.write(os.path.join("data", "plate", subdirs, file))
                    f.write("\n")
